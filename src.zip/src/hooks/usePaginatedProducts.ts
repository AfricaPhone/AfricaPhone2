// src/hooks/usePaginatedProducts.ts
import { useState, useCallback, useRef } from 'react';
import {
  collection,
  query,
  where,
  orderBy,
  limit,
  startAfter,
  getDocs,
  FirebaseFirestoreTypes, // Importation principale des types
} from '@react-native-firebase/firestore';
import { db } from '../firebase/config';
import { Product } from '../types';

const PAGE_SIZE = 10;

// Options pour la requête
export interface ProductQueryOptions {
  category?: string;
  brandId?: string; // NOUVELLE OPTION
  sortBy?: 'price' | 'rating' | 'name';
  sortDirection?: 'asc' | 'desc';
  searchQuery?: string;
  // NOUVELLES OPTIONS DE FILTRE DE PRIX
  minPrice?: string;
  maxPrice?: string;
}

// Convertit un document Firestore en type Product
const mapDocToProduct = (doc: FirebaseFirestoreTypes.QueryDocumentSnapshot): Product => {
  const data = doc.data();
  return {
    id: doc.id,
    title: data.name,
    price: data.price,
    image: data.imageUrl,
    category: data.brand?.toLowerCase() || 'inconnu',
    rating: data.rating || 4.5,
    description: data.description,
    rom: data.rom,
    ram: data.ram,
    ram_base: data.ram_base,
    ram_extension: data.ram_extension,
  };
};

export const usePaginatedProducts = (options: ProductQueryOptions = {}) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(true);

  // Garde une référence au dernier document pour la pagination
  const lastDocRef = useRef<FirebaseFirestoreTypes.QueryDocumentSnapshot | null>(null);

  // Fonction pour construire la requête Firestore
  const buildQuery = useCallback((): FirebaseFirestoreTypes.Query => {
    let q: FirebaseFirestoreTypes.Query = collection(db, 'products');

    // Ajout des clauses `where` en fonction des options de filtre
    if (options.brandId) {
      q = query(q, where('brand', '==', options.brandId));
    } else if (options.category && options.category !== 'Populaires') {
      const categoryCapitalized = options.category.charAt(0).toUpperCase() + options.category.slice(1);
      q = query(q, where('category', '==', categoryCapitalized));
    }

    // Ajout des filtres de prix
    const minPriceNum = Number(options.minPrice);
    const maxPriceNum = Number(options.maxPrice);

    // NOUVELLE LOGIQUE POUR GÉRER L'INÉGALITÉ ET LE TRI
    const hasPriceFilter = !isNaN(minPriceNum) || !isNaN(maxPriceNum);

    if (!isNaN(minPriceNum) && minPriceNum > 0) {
      q = query(q, where('price', '>=', minPriceNum));
    }
    if (!isNaN(maxPriceNum) && maxPriceNum > 0) {
      q = query(q, where('price', '<=', maxPriceNum));
    }

    if (options.searchQuery) {
      q = query(
        q,
        where('name', '>=', options.searchQuery),
        where('name', '<=', options.searchQuery + '\uf8ff')
      );
    }

    // Le tri doit maintenant respecter l'ordre si un filtre de prix est présent
    if (hasPriceFilter) {
      // Si un filtre de prix est présent, la clause de tri par prix DOIT être la première
      q = query(q, orderBy('price', options.sortDirection || 'asc'));
      // On peut ensuite appliquer une deuxième clause de tri si une autre est spécifiée
      if (options.sortBy && options.sortBy !== 'price') {
        q = query(q, orderBy(options.sortBy, options.sortDirection || 'asc'));
      }
    } else if (options.sortBy) {
      // Si aucun filtre de prix, on applique simplement le tri demandé
      q = query(q, orderBy(options.sortBy, options.sortDirection || 'asc'));
    } else {
      // Tri par défaut
      q = query(q, orderBy('name', 'asc'));
    }

    return q;
  }, [
    options.category,
    options.brandId,
    options.sortBy,
    options.sortDirection,
    options.searchQuery,
    options.minPrice,
    options.maxPrice,
  ]);

  const fetchProducts = useCallback(
    async (isInitial = false) => {
      if (isInitial) {
        setLoading(true);
        lastDocRef.current = null; // Réinitialiser pour le premier chargement
      } else {
        if (loadingMore || !hasMore) return;
        setLoadingMore(true);
      }

      try {
        let q = buildQuery();
        q = query(q, limit(PAGE_SIZE));

        if (!isInitial && lastDocRef.current) {
          q = query(q, startAfter(lastDocRef.current));
        }

        const querySnapshot = await getDocs(q);
        const newProducts = querySnapshot.docs.map(mapDocToProduct);

        lastDocRef.current = querySnapshot.docs[querySnapshot.docs.length - 1] || null;
        setHasMore(newProducts.length === PAGE_SIZE);

        if (isInitial) {
          setProducts(newProducts);
        } else {
          setProducts(prev => [...prev, ...newProducts]);
        }
      } catch (error) {
        console.error('Erreur de chargement des produits: ', error);
      } finally {
        setLoading(false);
        setLoadingMore(false);
      }
    },
    [buildQuery, hasMore, loadingMore]
  );

  const refresh = useCallback(() => {
    fetchProducts(true);
  }, [fetchProducts]);

  return { products, loading, loadingMore, hasMore, loadMore: () => fetchProducts(false), refresh };
};
